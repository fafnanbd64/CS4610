package v1.v1.main;

public class one {
    public static void main(String[] args) {
        
        largestRec b = new largestRec();
        int area = b.calc();
        System.out.println("Result: " + area);
        
    }
}